This is a simple script to remove illegit attributes for svg tags.

Usage: pyton3 strip_sttr.py -a <atribute_name> -i <inputfile_name>

A copy of modified file will be output as inputfile_name-0x.svg